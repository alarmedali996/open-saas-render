# QAOO-AI

Responsive business-toolkit starter for product descriptions, social captions and customer replies.

## Current status
This is a static front-end prototype. Its tools generate editable starter templates in the browser; they are **not connected to a live AI model**, user accounts, a database, subscriptions or payment processing.

## Run locally
Open `index.html` in a browser.

## Deploy on Render
Create a Static Site from this repository, branch `main`, publish directory `.`, and build command `echo "No build step required"`.

## Planned integrations
- Secure server-side AI provider integration (never put API keys in browser code).
- Authentication including Google OAuth after credentials and redirect URLs are configured.
- Database-backed user settings and usage limits.
- Payment provider integration after the business and account requirements are confirmed.

Contact: alarmedali996@gmail.com
